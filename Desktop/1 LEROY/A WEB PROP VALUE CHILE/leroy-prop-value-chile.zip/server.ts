import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", market: "Chile", currency: "UF" });
});

// Mock Market Data API
app.get("/api/market-stats", (req, res) => {
  res.json([
    { commune: "Las Condes", avgPriceUF: 12500, trend: "+2.4%" },
    { commune: "Providencia", avgPriceUF: 8900, trend: "+1.8%" },
    { commune: "Santiago", avgPriceUF: 3200, trend: "-0.5%" },
    { commune: "Ñuñoa", avgPriceUF: 5400, trend: "+3.1%" },
    { commune: "Vitacura", avgPriceUF: 15800, trend: "+1.2%" },
  ]);
});

async function setupServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production: Serve static files from dist
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Only listen if not running in a serverless environment (like Vercel)
  if (process.env.VERCEL !== "1") {
    const PORT = parseInt(process.env.PORT || "3000", 10);
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`PropValue Chile Server running on http://localhost:${PORT}`);
    });
  }
}

setupServer();

export default app;
