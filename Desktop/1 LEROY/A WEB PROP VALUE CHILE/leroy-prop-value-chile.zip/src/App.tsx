import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ValuationForm } from './components/ValuationForm';
import { MarketTrends } from './components/MarketTrends';
import { MarketMap } from './components/MarketMap';
import { ProjectList } from './components/ProjectList';
import { PropertyData, ValuationResult, MarketStat, Project } from './types';
import { estimatePropertyValue } from './services/geminiService';
import { useFirebase } from './components/FirebaseProvider';
import { db, handleFirestoreError, OperationType } from './firebase';
import { collection, addDoc, query, where, orderBy, limit, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { Building2, TrendingUp, MapPin, Calculator, Info, LogOut, LogIn, Download, FileText, X, CheckCircle2, Map as MapIcon, History } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

export default function App() {
  const { user, loading: authLoading, login, logout } = useFirebase();
  const [valuation, setValuation] = useState<ValuationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [marketStats, setMarketStats] = useState<MarketStat[]>([]);
  const [ufValue, setUfValue] = useState(38500); // Fallback value
  const [history, setHistory] = useState<ValuationResult[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeTab, setActiveTab] = useState<'valuation' | 'projects'>('valuation');
  const [isDownloading, setIsDownloading] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  // Fetch real-time UF value
  useEffect(() => {
    const fetchUF = async () => {
      try {
        const response = await fetch('https://mindicador.cl/api/uf');
        const data = await response.json();
        if (data.serie && data.serie.length > 0) {
          setUfValue(data.serie[0].valor);
        }
      } catch (error) {
        console.error('Error fetching UF value:', error);
      }
    };
    fetchUF();
  }, []);

  useEffect(() => {
    fetch('/api/market-stats')
      .then(res => res.json())
      .then(setMarketStats);
  }, []);

  // Sync projects from Firestore
  useEffect(() => {
    const q = query(collection(db, 'projects'), limit(20));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projectList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as unknown as Project[];
      setProjects(projectList);
      
      // Seed mock data if empty
      if (projectList.length === 0) {
        seedMockProjects();
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
    });
    return () => unsubscribe();
  }, []);

  const seedMockProjects = async () => {
    const mockProjects: Partial<Project>[] = [
      {
        name: "Edificio Biobío Central",
        developer: "Inmobiliaria Sur",
        property_type: 'Departamento',
        region: "Biobío",
        commune: "Concepción",
        sector: "Centro",
        zoning_code: "ZH-1",
        address: "Av. Chacabuco 1234",
        status: "En Venta",
        floors: 15,
        total_units: 120,
        amenities: ["Piscina", "Quincho", "Gimnasio"],
        sustainability_features: ["Paneles Solares", "Aislación Térmica"],
        avg_price_uf_m2: 65,
        coordinates: { lat: -36.827, lng: -73.050 }
      },
      {
        name: "Edificio Parque Ecuador",
        developer: "Inmobiliaria Concepción",
        property_type: 'Departamento',
        region: "Biobío",
        commune: "Concepción",
        sector: "Parque Ecuador",
        zoning_code: "ZH-2",
        address: "Víctor Lamas 1050",
        status: "Entrega Inmediata",
        floors: 12,
        total_units: 85,
        amenities: ["Gimnasio", "Sala de Cine", "Lavandería"],
        sustainability_features: ["Reciclaje de Aguas Grises"],
        avg_price_uf_m2: 72,
        coordinates: { lat: -36.833, lng: -73.045 }
      },
      {
        name: "Torre Santiago Oriente",
        developer: "Inmobiliaria Capital",
        property_type: 'Departamento',
        region: "Metropolitana",
        commune: "Las Condes",
        sector: "El Golf",
        zoning_code: "UC-1",
        address: "Av. Apoquindo 5678",
        status: "Entrega Inmediata",
        floors: 22,
        total_units: 180,
        amenities: ["Piscina Panorámica", "Cowork", "Lavandería"],
        sustainability_features: ["Certificación LEED", "Puntos de Reciclaje"],
        avg_price_uf_m2: 95,
        coordinates: { lat: -33.412, lng: -70.566 }
      },
      {
        name: "Residencial San Pedro",
        developer: "Inmobiliaria del Mar",
        property_type: 'Departamento',
        region: "Biobío",
        commune: "San Pedro de la Paz",
        sector: "Andalué",
        zoning_code: "ZH-3",
        address: "Av. Michimalonco 450",
        status: "En Verde",
        floors: 12,
        total_units: 90,
        amenities: ["Piscina", "Juegos Infantiles", "Club House"],
        sustainability_features: ["Eficiencia Energética", "Riego Automático"],
        avg_price_uf_m2: 58,
        coordinates: { lat: -36.845, lng: -73.065 }
      },
      {
        name: "Condominio Huertos Familiares",
        developer: "Inmobiliaria Los Huertos",
        property_type: 'Casa',
        region: "Biobío",
        commune: "San Pedro de la Paz",
        sector: "Huertos Familiares",
        zoning_code: "ZH-4",
        address: "Los Canelos 1200",
        status: "En Venta",
        floors: 5,
        total_units: 40,
        amenities: ["Quincho", "Áreas Verdes", "Seguridad 24/7"],
        sustainability_features: ["Iluminación LED", "Aislación Térmica"],
        avg_price_uf_m2: 62,
        coordinates: { lat: -36.852, lng: -73.078 }
      },
      {
        name: "Edificio Ñuñoa Life",
        developer: "Inmobiliaria Urbana",
        property_type: 'Departamento',
        region: "Metropolitana",
        commune: "Ñuñoa",
        sector: "Plaza Ñuñoa",
        zoning_code: "ZH-5",
        address: "Av. Irarrázaval 2345",
        status: "En Venta",
        floors: 18,
        total_units: 150,
        amenities: ["Piscina", "Quincho", "Sala Multiuso"],
        sustainability_features: ["Ventanas Termopanel", "Reciclaje"],
        avg_price_uf_m2: 78,
        coordinates: { lat: -33.454, lng: -70.601 }
      },
      {
        name: "Sitio Industrial Lomas",
        developer: "Lomas Land",
        property_type: 'Sitio Eriazo',
        region: "Biobío",
        commune: "Concepción",
        sector: "Lomas de San Sebastián",
        zoning_code: "ZE-1",
        address: "Av. Jorge Alessandri s/n",
        status: "En Venta",
        floors: 0,
        total_units: 1,
        amenities: [],
        sustainability_features: [],
        avg_price_uf_m2: 12,
        coordinates: { lat: -36.795, lng: -73.040 }
      }
    ];

    for (const p of mockProjects) {
      await addDoc(collection(db, 'projects'), p);
    }
  };

  // Sync valuations from Firestore
  useEffect(() => {
    if (!user) {
      setHistory([]);
      return;
    }

    const q = query(
      collection(db, 'valuations'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(10)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const valuations = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as unknown as ValuationResult[];
      setHistory(valuations);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'valuations');
    });

    return () => unsubscribe();
  }, [user]);

  const loadDemoValuation = () => {
    const mockValuation: ValuationResult = {
      estimated_price_uf: 5250,
      estimated_price_clp: Math.round(5250 * ufValue),
      confidence_score: 0.94,
      market_context: "Propiedad de ejemplo ubicada en sector consolidado de Las Condes. El valor refleja una excelente conservación, orientación oriente y cercanía a servicios premium. Se considera un factor de plusvalía del 4.5% anual para el sector.",
      regulatory_analysis: {
        compliance_score: 1.0,
        is_consistent: true,
        observations: "Los parámetros de altura (15 pisos) y constructibilidad (2.5) son plenamente consistentes con la zona UC-1 del Plano Regulador de Las Condes para el sector El Golf."
      },
      comparables: [
        { price_uf: 5400, m2: 75, distance_km: 0.2, source: "Venta Reciente CBRS - El Golf" },
        { price_uf: 5150, m2: 72, distance_km: 0.4, source: "Portal Inmobiliario - Depto Similar" },
        { price_uf: 5300, m2: 78, distance_km: 0.6, source: "TocToc - Oferta Competitiva" }
      ]
    };
    setValuation(mockValuation);
    setShowReport(true);
  };

  const handleValuation = async (data: PropertyData) => {
    console.log("handleValuation called with data:", JSON.stringify(data, null, 2));
    if (!user) {
      console.warn("User not logged in, cannot perform valuation");
      alert("Por favor, inicia sesión para realizar una tasación.");
      return;
    }

    setIsLoading(true);
    setValuation(null); // Clear previous result
    try {
      console.log("Calling estimatePropertyValue with timeout...");
      
      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("TIMEOUT")), 30000)
      );

      const result = await Promise.race([
        estimatePropertyValue(data, ufValue),
        timeoutPromise
      ]) as ValuationResult;

      console.log("estimatePropertyValue success, result:", JSON.stringify(result, null, 2));
      setValuation(result);
      setShowReport(true);
      
      // Save to Firestore
      console.log("Saving valuation to Firestore...");
      await addDoc(collection(db, 'valuations'), {
        ...data,
        ...result,
        userId: user.uid,
        createdAt: serverTimestamp(),
      });
      console.log("Valuation saved successfully to Firestore");
    } catch (error) {
      console.error("Valuation error caught in App.tsx:", error);
      if (error instanceof Error && error.message === "TIMEOUT") {
        alert("La tasación está tomando más tiempo de lo esperado. Por favor, intenta de nuevo en unos momentos.");
      } else {
        alert("Hubo un error al procesar la tasación. Por favor, intenta de nuevo.");
      }
      handleFirestoreError(error, OperationType.CREATE, 'valuations');
    } finally {
      setIsLoading(false);
      console.log("handleValuation finished, isLoading set to false");
    }
  };

  const downloadPDF = async () => {
    if (!reportRef.current || !valuation) return;
    
    setIsDownloading(true);
    try {
      // Ensure the element is visible and scrolled to top for capture
      const element = reportRef.current;
      
      // Use html2canvas with better options for production/Vercel
      const canvas = await html2canvas(element, {
        scale: 3, // Higher scale for better PDF quality
        useCORS: true, // Crucial for external images
        allowTaint: true,
        logging: false,
        backgroundColor: "#ffffff", // Ensure white background
        windowWidth: element.scrollWidth,
        windowHeight: element.scrollHeight,
      });
      
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
        compress: true
      });
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgProps = pdf.getImageProperties(imgData);
      const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      // If content is longer than one page, we might need to handle it, 
      // but for this report one page is usually enough or we can scale it.
      pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, imgHeight, undefined, 'FAST');
      
      const fileName = `Tasacion_${valuation.estimated_price_uf}UF_${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(fileName);
      
      console.log("PDF generated successfully:", fileName);
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Hubo un error al generar el PDF. Por favor, inténtalo de nuevo.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      {/* Loading Overlay */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-blue-900/40 backdrop-blur-md"
          >
            <div className="bg-white p-8 rounded-3xl shadow-2xl text-center max-w-sm mx-4">
              <div className="relative w-20 h-20 mx-auto mb-6">
                <div className="absolute inset-0 border-4 border-blue-100 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
                <Calculator className="absolute inset-0 m-auto w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Calculando Tasación</h3>
              <p className="text-gray-500 text-sm leading-relaxed">
                Nuestra IA está analizando el mercado, normativas urbanas y comparables para entregarte el valor más preciso.
              </p>
              <div className="mt-6 flex gap-1 justify-center">
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 md:px-6 py-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Building2 className="text-blue-600 w-8 h-8 flex-shrink-0" />
            <div className="flex flex-col">
              <h1 className="text-lg md:text-2xl font-bold tracking-tight leading-none">LeRoy-<span className="text-orange-leroy">Prop value Chile</span></h1>
              <a 
                href="https://leroyresidence.cl" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[8px] md:text-[10px] text-gray-400 font-medium mt-0.5 uppercase tracking-widest hover:text-blue-600 transition-colors"
              >
                leroyresidence.cl
              </a>
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Calculator className="w-6 h-6" />}
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
            <button 
              onClick={() => setActiveTab('valuation')}
              className={`flex flex-col items-center hover:text-blue-600 transition-colors ${activeTab === 'valuation' ? 'text-blue-600 border-b-2 border-blue-600' : ''}`}
            >
              <span>Tasación</span>
              <span className="text-[9px] text-blue-800 font-bold">Valor comercial</span>
            </button>
            <button 
              onClick={() => setActiveTab('projects')}
              className={`flex flex-col items-center hover:text-blue-600 transition-colors ${activeTab === 'projects' ? 'text-blue-600 border-b-2 border-blue-600' : ''}`}
            >
              <span>Nuevos Proyectos</span>
              <span className="text-[9px] text-blue-800 font-bold">Inversión y futuro</span>
            </button>
            <div className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">
              UF: ${ufValue.toLocaleString('es-CL')}
            </div>
            {user && valuation && (
              <button 
                onClick={() => setValuation(null)}
                className="cta-top scale-75 lg:scale-90"
              >
                + Nueva Tasación
              </button>
            )}
            {user ? (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <img src={user.photoURL || ''} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-gray-200" referrerPolicy="no-referrer" />
                  <span className="font-semibold">{user.displayName}</span>
                </div>
                <button onClick={logout} className="flex items-center gap-1 text-red-600 hover:text-red-700 transition-colors">
                  <LogOut className="w-4 h-4" />
                  Salir
                </button>
              </div>
            ) : (
              <button onClick={login} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors">
                <LogIn className="w-4 h-4" />
                Ingresar
              </button>
            )}
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-gray-100 overflow-hidden"
            >
              <div className="flex flex-col p-4 gap-4">
                <button 
                  onClick={() => { setActiveTab('valuation'); setIsMobileMenuOpen(false); }}
                  className={`flex items-center gap-3 p-3 rounded-xl ${activeTab === 'valuation' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'}`}
                >
                  <Calculator className="w-5 h-5" />
                  <span className="font-bold">Tasación Comercial</span>
                </button>
                <button 
                  onClick={() => { setActiveTab('projects'); setIsMobileMenuOpen(false); }}
                  className={`flex items-center gap-3 p-3 rounded-xl ${activeTab === 'projects' ? 'bg-blue-50 text-blue-600' : 'text-gray-600'}`}
                >
                  <Building2 className="w-5 h-5" />
                  <span className="font-bold">Nuevos Proyectos</span>
                </button>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">Valor UF Hoy</span>
                  <span className="text-blue-700 font-bold">${ufValue.toLocaleString('es-CL')}</span>
                </div>
                {user ? (
                  <div className="flex flex-col gap-3 pt-2 border-t border-gray-100">
                    <div className="flex items-center gap-3 p-2">
                      <img src={user.photoURL || ''} alt={user.displayName || ''} className="w-10 h-10 rounded-full border border-gray-200" referrerPolicy="no-referrer" />
                      <div>
                        <p className="font-bold text-gray-900">{user.displayName}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => { logout(); setIsMobileMenuOpen(false); }}
                      className="flex items-center justify-center gap-2 p-3 text-red-600 font-bold bg-red-50 rounded-xl"
                    >
                      <LogOut className="w-5 h-5" />
                      Cerrar Sesión
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => { login(); setIsMobileMenuOpen(false); }}
                    className="flex items-center justify-center gap-2 p-4 bg-blue-600 text-white font-bold rounded-xl shadow-lg"
                  >
                    <LogIn className="w-5 h-5" />
                    Ingresar con Google
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero Section - Instructions */}
      {!valuation && activeTab === 'valuation' && (
        <motion.section 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="hero py-8 md:py-16"
        >
          <div className="w-full flex flex-col items-center">
            <div className="hero-title-banner flex-col px-4">
              <h1 className="text-2xl md:text-4xl lg:text-5xl text-center">
                Tasación Inteligente en Segundos
              </h1>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mt-8 max-w-4xl mx-auto w-full">
                <button 
                  onClick={() => document.getElementById('market-map')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Mapa de Oportunidades
                </button>
                <button 
                  onClick={() => document.getElementById('market-trends')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Análisis de Mercado
                </button>
                <button 
                  onClick={() => document.getElementById('valuation-history')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Historial
                </button>
                <button 
                  onClick={() => document.getElementById('market-stats')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Mercado por Comuna
                </button>
                <button 
                  onClick={() => {
                    setActiveTab('projects');
                    setTimeout(() => document.getElementById('projects-list')?.scrollIntoView({ behavior: 'smooth' }), 100);
                  }}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Proyectos
                </button>
                <button 
                  onClick={() => document.getElementById('plusvalia')?.scrollIntoView({ behavior: 'smooth' })}
                  className="hero-nav-btn text-[10px] md:text-xs py-3 px-2 h-full flex items-center justify-center text-center"
                >
                  Plusvalía
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 mb-8 w-full max-w-6xl px-4 items-stretch">
              <div className="valuation-pillar p-4 md:p-6">
                <div className="pillar-icon mb-4">
                  <Calculator className="w-6 h-6 md:w-7 h-7" />
                </div>
                <h3 className="text-base md:text-lg font-bold mb-2">Técnico y Normativo</h3>
                <p className="text-[10px] text-blue-900 mb-3 italic font-bold leading-tight">Analizamos el Plan Regulador, zonificación y normas del SII para saber qué se permite construir.</p>
                <div className="w-full">
                  <p className="pillar-subtitle text-[11px] mb-2">Aspectos que considera:</p>
                  <ul className="pillar-list text-[10px] space-y-1">
                    <li><span>•</span> Rol de Avalúo SII</li>
                    <li><span>•</span> Zonificación (PRC)</li>
                    <li><span>•</span> Coef. Constructibilidad</li>
                    <li><span>•</span> Rasantes y Densidad</li>
                  </ul>
                </div>
              </div>
              
              <div className="valuation-pillar p-4 md:p-6">
                <div className="pillar-icon mb-4">
                  <TrendingUp className="w-6 h-6 md:w-7 h-7" />
                </div>
                <h3 className="text-base md:text-lg font-bold mb-2">Análisis de Mercado</h3>
                <p className="text-[10px] text-blue-900 mb-3 italic font-bold leading-tight">Comparamos con ventas reales y oferta actual en el sector para determinar el valor de mercado.</p>
                <div className="w-full">
                  <p className="pillar-subtitle text-[11px] mb-2">Aspectos que considera:</p>
                  <ul className="pillar-list text-[10px] space-y-1">
                    <li><span>•</span> Testigos de Venta</li>
                    <li><span>•</span> Oferta Competitiva</li>
                    <li><span>•</span> Plusvalía de Zona</li>
                    <li><span>•</span> Valor UF/m² Promedio</li>
                  </ul>
                </div>
              </div>

              <div className="valuation-pillar p-4 md:p-6">
                <div className="pillar-icon mb-4">
                  <Building2 className="w-6 h-6 md:w-7 h-7" />
                </div>
                <h3 className="text-base md:text-lg font-bold mb-2">Atributos Propiedad</h3>
                <p className="text-[10px] text-blue-900 mb-3 italic font-bold leading-tight">Evaluamos el estado, terminaciones y equipamiento que hacen única a tu propiedad.</p>
                <div className="w-full">
                  <p className="pillar-subtitle text-[11px] mb-2">Aspectos que considera:</p>
                  <ul className="pillar-list text-[10px] space-y-1">
                    <li><span>•</span> Superficie Útil/Total</li>
                    <li><span>•</span> Calidad de Terminaciones</li>
                    <li><span>•</span> Orientación y Vista</li>
                    <li><span>•</span> Equipamiento Común</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4 md:gap-6 mt-4 px-4">
              <button 
                onClick={() => {
                  const formElement = document.getElementById('valuation-form');
                  formElement?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="cta-main text-sm md:text-base py-3 px-6"
              >
                Obtener Tasación
              </button>

              <button 
                onClick={loadDemoValuation}
                className="cta-main text-sm md:text-base py-3 px-6 bg-purple-600 hover:bg-purple-700 border-purple-500"
              >
                Ver Ejemplo de Informe
              </button>

              <button 
                onClick={() => {
                  const formElement = document.getElementById('valuation-form');
                  formElement?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="cta-main text-sm md:text-base py-3 px-6"
              >
                Tasación Gratis
              </button>
            </div>
          </div>
        </motion.section>
      )}

      {/* Form Section - Full Width */}
      <section id="valuation-form" className="w-full bg-white border-b border-gray-100">
        {user ? (
          <ValuationForm onSubmit={handleValuation} isLoading={isLoading} />
        ) : (
          <div className="max-w-7xl mx-auto px-6 py-12">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 text-center max-w-2xl mx-auto">
              <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <LogIn className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Inicia Sesión</h3>
              <p className="text-gray-600 mb-6 text-sm">Debes ingresar para realizar tasaciones y guardar tu historial.</p>
              <button onClick={login} className="w-full bg-blue-600 text-white font-semibold py-3 rounded-xl hover:bg-blue-700 transition-colors">
                Ingresar con Google
              </button>
            </div>
          </div>
        )}
      </section>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Stats */}
          <div id="market-stats" className="lg:col-span-4 space-y-8">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-500" />
                Mercado por Comuna
              </h3>
              <div className="space-y-3">
                {marketStats.map(stat => (
                  <div key={stat.commune} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded-lg transition-colors">
                    <span className="text-sm font-medium">{stat.commune}</span>
                    <div className="text-right">
                      <div className="text-sm font-bold">{stat.avgPriceUF.toLocaleString()} UF</div>
                      <div className={`text-xs ${stat.trend.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                        {stat.trend}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Results & Charts */}
          <div className="lg:col-span-8 space-y-8">
          <AnimatePresence mode="wait">
            {activeTab === 'valuation' ? (
              <motion.div
                key="valuation-tab"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                {valuation ? (
                  <div className="space-y-4">
                    <motion.div 
                      key="result"
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-blue-600 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden"
                    >
                      <div className="relative z-10">
                        <div className="flex justify-between items-start mb-6">
                          <div>
                            <p className="text-orange-leroy/80 text-sm font-medium uppercase tracking-wider">Estimación Prop value</p>
                            <h2 className="text-5xl font-bold mt-1">
                              {valuation.estimated_price_uf.toLocaleString()} <span className="text-2xl font-normal">UF</span>
                            </h2>
                            <p className="text-blue-200 mt-1 text-lg">
                              ≈ ${valuation.estimated_price_clp.toLocaleString('es-CL')} CLP
                            </p>
                          </div>
                          <div className="flex flex-col items-end gap-3">
                            <div className="bg-white/20 backdrop-blur-md p-3 rounded-2xl text-center min-w-[100px]">
                              <p className="text-xs font-bold uppercase">Confianza</p>
                              <p className="text-2xl font-bold">{(valuation.confidence_score * 100).toFixed(0)}%</p>
                            </div>
                          </div>
                        </div>

                        <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl mb-6">
                          <div className="flex gap-2 items-start">
                            <Info className="w-5 h-5 mt-0.5 flex-shrink-0" />
                            <p className="text-sm leading-relaxed">{valuation.market_context}</p>
                          </div>
                        </div>

                        <div className="flex justify-center mb-6">
                          <button 
                            onClick={() => setShowReport(true)}
                            className="bg-white text-blue-600 px-6 py-2 rounded-xl font-bold hover:bg-blue-50 transition-all shadow-lg flex items-center gap-2"
                          >
                            <FileText className="w-5 h-5" />
                            Ver Informe Completo
                          </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {valuation.comparables.map((comp, idx) => (
                            <div key={idx} className="bg-white/10 p-3 rounded-xl border border-white/10">
                              <p className="text-xs text-blue-100 mb-1">{comp.source}</p>
                              <p className="font-bold">{comp.price_uf} UF</p>
                              <p className="text-xs text-blue-200">{comp.m2} m² • {comp.distance_km} km</p>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-blue-500 rounded-full blur-3xl opacity-50"></div>
                    </motion.div>
                  </div>
                ) : null}
                
                <div id="market-trends">
                  <MarketTrends />
                </div>
                
                <div className={`grid grid-cols-1 ${user ? 'lg:grid-cols-3' : ''} gap-6`}>
                  <div id="market-map" className={user ? 'lg:col-span-2' : ''}>
                    <MarketMap />
                  </div>

                  {user && (
                    <div id="valuation-history" className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-full">
                      <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center gap-2">
                        <TrendingUp className="text-blue-600 w-5 h-5" />
                        Tasaciones Recientes
                      </h2>
                      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                        {history.length === 0 ? (
                          <p className="text-gray-500 text-sm italic">No hay registros recientes.</p>
                        ) : (
                          history.map((item, idx) => (
                            <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100 hover:bg-gray-100 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="bg-blue-100 p-2 rounded-lg">
                                  <FileText className="w-4 h-4 text-blue-600" />
                                </div>
                                <div>
                                  <p className="font-medium text-gray-800 text-sm">{item.estimated_price_uf.toLocaleString()} UF</p>
                                  <p className="text-[10px] text-gray-500">Confianza: {(item.confidence_score * 100).toFixed(0)}%</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-xs text-blue-600 font-bold">${(item.estimated_price_clp / 1000000).toFixed(1)}M</p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="projects-tab"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div id="projects-list">
                  <ProjectList projects={projects} />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div id="plusvalia" className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h4 className="font-bold flex items-center gap-2 mb-4">
                <MapPin className="w-5 h-5 text-blue-600" />
                Zonas de Alta Plusvalía
              </h4>
              <ul className="space-y-3 text-sm">
                <li className="flex justify-between border-b border-gray-50 pb-2">
                  <span>Barrio Italia, Providencia</span>
                  <span className="text-green-600 font-bold">+12% anual</span>
                </li>
                <li className="flex justify-between border-b border-gray-50 pb-2">
                  <span>Eje Vicuña Mackenna, Ñuñoa</span>
                  <span className="text-green-600 font-bold">+8.5% anual</span>
                </li>
                <li className="flex justify-between">
                  <span>Sector El Golf, Las Condes</span>
                  <span className="text-green-600 font-bold">+5.2% anual</span>
                </li>
              </ul>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col justify-center items-center text-center">
              <p className="text-sm text-gray-500 mb-2">¿Eres corredor de propiedades?</p>
              <button className="bg-gray-900 text-white px-6 py-2 rounded-xl text-sm font-bold hover:bg-gray-800 transition-colors">
                Acceso Profesional
              </button>
            </div>
          </div>

          </div>
        </div>
      </main>

      {/* Biobío Specific Insights - Full Width */}
      <section className="w-full bg-gradient-to-br from-blue-700 to-blue-900 py-20 text-white shadow-inner">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col gap-12">
            <div className="max-w-3xl">
              <h3 className="text-4xl font-bold mb-6 flex items-center gap-4">
                <Info className="w-10 h-10 text-blue-300" />
                Análisis Instrumentos Técnicos Considerados
              </h3>
              <p className="text-blue-100 text-xl leading-relaxed">
                Nuestra plataforma integra datos geoespaciales críticos y normativas de la Región del Biobío, 
                asegurando que cada tasación se fundamente en los instrumentos técnicos vigentes y el análisis territorial preciso.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white/10 backdrop-blur-md p-8 rounded-3xl border border-white/10 hover:bg-white/20 transition-all duration-300 group">
                <p className="text-xs text-blue-300 uppercase tracking-widest font-bold mb-3">Normativa Urbana</p>
                <p className="font-bold text-xl mb-3 group-hover:text-blue-200 transition-colors">Concepción Centro (PRC)</p>
                <p className="text-blue-100/90 text-sm leading-relaxed">
                  El Plan Regulador Comunal (PRC) en su zonificación ZH-1 permite alta densidad, 
                  siendo el principal motor para proyectos mixtos y la renovación urbana del casco histórico.
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-md p-8 rounded-3xl border border-white/10 hover:bg-white/20 transition-all duration-300 group">
                <p className="text-xs text-blue-300 uppercase tracking-widest font-bold mb-3">Plusvalía & Vistas</p>
                <p className="font-bold text-xl mb-3 group-hover:text-blue-200 transition-colors">San Pedro (Andalué/Huertos)</p>
                <p className="text-blue-100/90 text-sm leading-relaxed">
                  Consideramos las restricciones de altura específicas en zonas residenciales exclusivas, 
                  un factor determinante para preservar la plusvalía y el valor de las vistas privilegiadas.
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur-md p-8 rounded-3xl border border-white/10 hover:bg-white/20 transition-all duration-300 group">
                <p className="text-xs text-blue-300 uppercase tracking-widest font-bold mb-3">Riesgos & Seguridad</p>
                <p className="font-bold text-xl mb-3 group-hover:text-blue-200 transition-colors">Sistema GIS Municipal</p>
                <p className="text-blue-100/90 text-sm leading-relaxed">
                  Integramos capas de riesgo (inundación y remoción en masa) del sistema de información geográfica, 
                  garantizando tasaciones que reflejan la seguridad real del terreno.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-gray-200 mt-12 text-center text-gray-500 text-sm">
        <p>© 2026 LeRoy-<span className="text-orange-leroy">Prop value Chile</span>. <a href="https://leroyresidence.cl" target="_blank" rel="noopener noreferrer" className="hover:text-blue-600 transition-colors underline underline-offset-2">leroyresidence.cl</a>.</p>
        <p className="mt-1">Datos procesados de SII, CBRS y Portales Inmobiliarios.</p>
      </footer>

      {/* Report Modal - "Hoja Nueva" */}
      <AnimatePresence>
        {showReport && valuation && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl relative"
            >
              <button 
                onClick={() => setShowReport(false)}
                className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full transition-colors z-20"
              >
                <X className="w-6 h-6 text-gray-500" />
              </button>

              <div ref={reportRef} className="p-8 md:p-12 bg-white report-pdf-container">
                {/* Header of the report */}
                <div className="flex justify-between items-start mb-12 border-b border-gray-100 pb-8">
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Building2 className="text-blue-600 w-8 h-8" />
                      <div className="flex flex-col">
                        <h1 className="text-2xl font-bold tracking-tight text-gray-900">LeRoy-<span className="text-orange-leroy">Prop value Chile</span></h1>
                        <a 
                          href="https://leroyresidence.cl" 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-[10px] text-gray-400 font-medium -mt-1 uppercase tracking-widest hover:text-blue-600 transition-colors"
                        >
                          leroyresidence.cl
                        </a>
                      </div>
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter">Informe de Tasación Inmobiliaria</h2>
                    <p className="text-gray-500 font-medium">Generado el {new Date().toLocaleDateString('es-CL')}</p>
                  </div>
                  <div className="text-right">
                    <div className="bg-blue-600 text-white px-4 py-2 rounded-xl inline-block font-bold mb-2">
                      CONFIDENCIAL
                    </div>
                    <p className="text-xs text-gray-400">ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
                  </div>
                </div>

                {/* Main Value Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
                  <div className="bg-gray-50 p-8 rounded-3xl border border-gray-100">
                    <p className="text-sm font-bold text-blue-600 uppercase tracking-widest mb-2">Valor Estimado de Mercado</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-6xl font-black text-gray-900">{valuation.estimated_price_uf.toLocaleString()}</span>
                      <span className="text-2xl font-bold text-gray-400">UF</span>
                    </div>
                    <p className="text-2xl font-bold text-gray-600 mt-2">
                      ${valuation.estimated_price_clp.toLocaleString('es-CL')} CLP
                    </p>
                    <div className="mt-6 flex items-center gap-2 text-sm text-gray-500">
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span>Basado en {valuation.comparables.length} comparables directos</span>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-3">Índice de Confianza</h4>
                      <div className="w-full bg-gray-100 h-4 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${valuation.confidence_score * 100}%` }}
                          className="h-full bg-blue-600"
                        />
                      </div>
                      <p className="text-right text-sm font-bold mt-1 text-blue-600">{(valuation.confidence_score * 100).toFixed(0)}%</p>
                    </div>
                    
                    <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
                      <h4 className="text-xs font-bold text-blue-800 uppercase mb-2">Análisis Técnico de Valoración</h4>
                      <p className="text-sm text-blue-900 leading-relaxed italic">
                        "{valuation.market_context}"
                      </p>
                    </div>

                    {valuation.regulatory_analysis && (
                      <div className={`p-4 rounded-2xl border ${valuation.regulatory_analysis.is_consistent ? 'bg-green-50 border-green-100' : 'bg-amber-50 border-amber-100'}`}>
                        <div className="flex items-center gap-2 mb-2">
                          <div className={`w-2 h-2 rounded-full ${valuation.regulatory_analysis.is_consistent ? 'bg-green-500' : 'bg-amber-500'}`} />
                          <h4 className={`text-xs font-bold uppercase ${valuation.regulatory_analysis.is_consistent ? 'text-green-800' : 'text-amber-800'}`}>
                            Verificación Normativa (PRC)
                          </h4>
                        </div>
                        <p className={`text-sm leading-relaxed ${valuation.regulatory_analysis.is_consistent ? 'text-green-900' : 'text-amber-900'}`}>
                          {valuation.regulatory_analysis.observations}
                        </p>
                        <div className="mt-2 text-[10px] font-bold uppercase opacity-60">
                          Consistencia: {(valuation.regulatory_analysis.compliance_score * 100).toFixed(0)}%
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Comparables Table */}
                <div className="mb-12">
                  <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                    <TrendingUp className="w-6 h-6 text-blue-600" />
                    Análisis de Comparables
                  </h3>
                  <div className="overflow-hidden rounded-2xl border border-gray-100">
                    <table className="w-full text-left">
                      <thead className="bg-gray-50 text-gray-500 text-xs font-bold uppercase">
                        <tr>
                          <th className="px-6 py-4">Fuente / Ubicación</th>
                          <th className="px-6 py-4 text-right">Precio (UF)</th>
                          <th className="px-6 py-4 text-right">Superficie (m²)</th>
                          <th className="px-6 py-4 text-right">Distancia</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {valuation.comparables.map((comp, idx) => (
                          <tr key={idx} className="text-sm hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4 font-medium text-gray-900">{comp.source}</td>
                            <td className="px-6 py-4 text-right font-bold text-blue-600">{comp.price_uf.toLocaleString()} UF</td>
                            <td className="px-6 py-4 text-right">{comp.m2} m²</td>
                            <td className="px-6 py-4 text-right text-gray-500">{comp.distance_km} km</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Footer / Disclaimer */}
                <div className="pt-8 border-t border-gray-100 text-[10px] text-gray-400 leading-relaxed">
                  <p className="mb-2 font-bold uppercase">Aviso Legal:</p>
                  <p>
                    Este informe es una estimación generada mediante modelos de inteligencia artificial y análisis de datos masivos (Big Data). 
                    No constituye una tasación bancaria oficial ni legal. Los valores pueden variar según condiciones específicas del inmueble 
                    no detectadas por el modelo. Se recomienda la validación por un tasador certificado para operaciones financieras críticas.
                  </p>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-between items-center sticky bottom-0 z-20">
                <button 
                  onClick={() => setShowReport(false)}
                  className="text-gray-500 font-bold hover:text-gray-700 transition-colors"
                >
                  Cerrar Vista
                </button>
                <div className="flex gap-3">
                  <button 
                    onClick={downloadPDF}
                    disabled={isDownloading}
                    className="flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg disabled:opacity-50"
                  >
                    {isDownloading ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white/20 border-t-white" />
                    ) : (
                      <Download className="w-5 h-5" />
                    )}
                    {isDownloading ? "Procesando..." : "Descargar PDF"}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
