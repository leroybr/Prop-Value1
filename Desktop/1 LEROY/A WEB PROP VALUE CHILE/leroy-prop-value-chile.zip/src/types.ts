export interface Project {
  id?: string;
  name: string;
  developer: string;
  property_type: 'Departamento' | 'Casa' | 'Sitio Eriazo' | 'Oficina' | 'Local Comercial' | 'Agrícola / Parcela';
  region: 'Biobío' | 'Metropolitana';
  commune: string;
  sector?: string;
  zoning_code?: string;
  address: string;
  status: 'En Venta' | 'En Verde' | 'Entrega Inmediata';
  floors: number;
  total_units: number;
  amenities: string[];
  sustainability_features: string[];
  avg_price_uf_m2: number;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface PropertyData {
  property_type: 'Departamento' | 'Casa' | 'Sitio Eriazo' | 'Oficina' | 'Local Comercial' | 'Agrícola / Parcela';
  rol_sii?: string;
  commune: string;
  sector?: string;
  zoning_code?: string;
  property_usage?: 'Habitacional' | 'Comercial' | 'Agrícola';
  m2_useful?: number;
  m2_total: number;
  bedrooms?: number;
  bathrooms?: number;
  parking?: number;
  storage?: number;
  year_built?: number;
  orientation?: string;
  gastos_comunes?: number;
  floors?: number;
  amenities?: string[];
  sustainability_features?: string[];
  project_status?: string;
  topography?: 'Plano' | 'Pendiente Suave' | 'Pendiente Fuerte';
  frontage_m?: number;
  max_height?: number; // Altura máxima permitida en pisos o metros
  constructability_index?: number; // Coeficiente de constructibilidad
  // New Factors that influence price
  conservation_state?: 'Excelente' | 'Bueno' | 'Regular' | 'Malo';
  construction_quality?: 'Superior' | 'Media' | 'Económica';
  proximity_to_metro?: boolean;
  proximity_to_services?: string[]; // e.g., ["Colegios", "Hospitales", "Comercio"]
  view_quality?: 'Despejada' | 'Parcial' | 'Obstruida';
  security_level?: 'Alta' | 'Media' | 'Baja';
  noise_level?: 'Silencioso' | 'Moderado' | 'Ruidoso';
  // Rural/Agricultural specific fields
  num_lots?: number;
  water_availability?: 'Abundante' | 'Suficiente' | 'Escasa';
  electricity_system?: 'Público' | 'Privado' | 'Generador';
  materiality_walls?: string;
  materiality_roof?: string;
  heating_system?: string;
  complementary_works?: string[]; // e.g., ["Piscina de Hormigón", "Bodegas"]
}

export interface ValuationResult {
  id?: string;
  estimated_price_uf: number;
  estimated_price_clp: number;
  confidence_score: number;
  comparables: ComparableProperty[];
  market_context: string;
  regulatory_analysis?: {
    compliance_score: number;
    observations: string;
    is_consistent: boolean;
  };
}

export interface ComparableProperty {
  price_uf: number;
  m2: number;
  distance_km: number;
  source: string;
}

export interface MarketStat {
  commune: string;
  avgPriceUF: number;
  trend: string;
}
