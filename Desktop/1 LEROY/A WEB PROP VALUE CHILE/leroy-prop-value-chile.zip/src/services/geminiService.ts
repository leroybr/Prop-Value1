import { GoogleGenAI, Type } from "@google/genai";
import { PropertyData, ValuationResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function estimatePropertyValue(data: PropertyData, ufValue: number): Promise<ValuationResult> {
  const prompt = `
    Act as a Senior Real Estate Appraiser (Tasador Inmobiliario Senior) and Data Scientist for the Chilean market.
    Your goal is to provide a professional valuation (AVM - Automated Valuation Model) similar to Zillow's Zestimate but tailored for Chile.

    Property Details:
    - Type: ${data.property_type}
    - Commune: ${data.commune}
    - Sector/Neighborhood: ${data.sector || "Not specified"}
    - Rol SII: ${data.rol_sii || "Not provided"}
    - Zoning Code (Plano Regulador): ${data.zoning_code || "Not specified"}
    - Destino (Usage): ${data.property_usage || "Not specified"}
    - Useful m2: ${data.m2_useful}
    - Total m2 (Land/Total): ${data.m2_total}
    - Bedrooms: ${data.bedrooms}
    - Bathrooms: ${data.bathrooms}
    - Parking: ${data.parking}
    - Storage: ${data.storage}
    - Year Built: ${data.year_built || "Unknown"}
    - Orientation: ${data.orientation || "Unknown"}
    - Floors in Building: ${data.floors || "Unknown"}
    - Amenities: ${data.amenities?.join(", ") || "None"}
    - Sustainability Features: ${data.sustainability_features?.join(", ") || "None"}
    - Project Status: ${data.project_status || "Unknown"}
    - Topography (for land): ${data.topography || "N/A"}
    - Frontage (meters): ${data.frontage_m || "N/A"}
    - Max Height Allowed: ${data.max_height || "Not specified"}
    - Constructability Index: ${data.constructability_index || "Not specified"}
    
    Valuation Factors:
    - State of Conservation: ${data.conservation_state || "Bueno"}
    - Construction Quality: ${data.construction_quality || "Media"}
    - View Quality: ${data.view_quality || "Parcial"}
    - Security Level: ${data.security_level || "Media"}
    - Noise Level: ${data.noise_level || "Moderado"}
    - Proximity to Metro: ${data.proximity_to_metro ? "Yes" : "No"}
    - Proximity to Services: ${data.proximity_to_services?.join(", ") || "None"}
    
    Rural/Agricultural Specifics (if applicable):
    - Number of Lots: ${data.num_lots || "N/A"}
    - Water Availability: ${data.water_availability || "N/A"}
    - Electricity System: ${data.electricity_system || "N/A"}
    - Materiality (Walls): ${data.materiality_walls || "N/A"}
    - Materiality (Roof): ${data.materiality_roof || "N/A"}
    - Heating System: ${data.heating_system || "N/A"}
    - Complementary Works: ${data.complementary_works?.join(", ") || "None"}

    Valuation Methodology (Inspired by Chilean Standards):
    1. Market Comparison (Metodología de Comparación): Analyze recent transactions and listings in ${data.commune} for ${data.property_type}.
    2. Replacement Cost (Coste de Reposición): For buildings, estimate construction cost minus depreciation.
    3. Residual Method (Metodología Residual) / Highest and Best Use (HBU): CRITICAL when land potential is high. If the land value (based on maximum potential development allowed by the "Plano Regulador Comunal" (PRC) and "OGUC") is higher than the value of the existing building + land as a single unit, the valuation MUST prioritize the land potential. This is especially relevant for houses on large lots with high constructability.
    4. Urban Norms Analysis: Consider specific constraints like:
       - Coefficient of Constructability (Coeficiente de Constructibilidad).
       - Land Occupation Coefficient (Coeficiente de Ocupación de Suelo).
       - Maximum Height (Altura Máxima).
       - Density (Densidad Máxima).
       - Setbacks and Separations (Rasantes y Distanciamientos).

    Regulatory & Market Context:
    - Current UF Value: ${ufValue} CLP.
    - Consider the "Plano Regulador Comunal" (PRC) constraints for ${data.commune}${data.sector ? ` in ${data.sector}` : ""}.
    - If Rol SII is provided, consider its impact on tax assessment and specific location.
    - Analyze the development potential based on the zoning code (${data.zoning_code || "Not specified"}).
    - Use the user-provided urban norms if available: Max Height (${data.max_height || "Not specified"}), Constructability Index (${data.constructability_index || "Not specified"}).
    - Focus on the specific dynamics of ${data.commune} (e.g., proximity to Metro, security trends, new developments).
    - Especial énfasis en Biobío (Concepción, San Pedro de la Paz) y Santiago (Región Metropolitana).

    Provide a professional valuation in JSON format. 
    The "market_context" MUST explicitly mention how the urban norms (normas urbanísticas) or the zoning code influenced the final value.
    The "regulatory_analysis" MUST verify if the provided Zoning Code (${data.zoning_code || "Not specified"}), Max Height (${data.max_height || "Not specified"}), and Constructability Index (${data.constructability_index || "Not specified"}) are consistent with the known "Plano Regulador Comunal" (PRC) of ${data.commune}.
    If they are inconsistent (e.g., a height of 50 floors in a low-density residential zone), mark "is_consistent" as false and explain why in "observations".
  `;

  console.log("Estimating property value with data:", data);
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            estimated_price_uf: { type: Type.NUMBER },
            confidence_score: { type: Type.NUMBER },
            market_context: { type: Type.STRING },
            regulatory_analysis: {
              type: Type.OBJECT,
              properties: {
                compliance_score: { type: Type.NUMBER },
                observations: { type: Type.STRING },
                is_consistent: { type: Type.BOOLEAN }
              },
              required: ["compliance_score", "observations", "is_consistent"]
            },
            comparables: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  price_uf: { type: Type.NUMBER },
                  m2: { type: Type.NUMBER },
                  distance_km: { type: Type.NUMBER },
                  source: { type: Type.STRING }
                },
                required: ["price_uf", "m2", "distance_km", "source"]
              }
            }
          },
          required: ["estimated_price_uf", "confidence_score", "market_context", "comparables", "regulatory_analysis"]
        }
      },
    });

    console.log("Gemini response received:", response);
    const result = JSON.parse(response.text || "{}");
    const estimated_price_uf = Number(result.estimated_price_uf);
    
    if (isNaN(estimated_price_uf) || estimated_price_uf <= 0) {
      console.error("Invalid price from Gemini:", result);
      throw new Error("La IA no pudo calcular un precio válido. Por favor, intenta de nuevo con más detalles.");
    }
    
    return {
      ...result,
      estimated_price_uf,
      estimated_price_clp: Math.round(estimated_price_uf * ufValue),
    };
  } catch (error) {
    console.error("Gemini API error:", error);
    throw error;
  }
}
