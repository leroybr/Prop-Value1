import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data: Record<string, any[]> = {
  'Metropolitana': [
    { month: 'Oct', price: 4200 },
    { month: 'Nov', price: 4350 },
    { month: 'Dic', price: 4300 },
    { month: 'Ene', price: 4450 },
    { month: 'Feb', price: 4600 },
    { month: 'Mar', price: 4550 },
  ],
  'Biobío': [
    { month: 'Oct', price: 3400 },
    { month: 'Nov', price: 3550 },
    { month: 'Dic', price: 3500 },
    { month: 'Ene', price: 3650 },
    { month: 'Feb', price: 3800 },
    { month: 'Mar', price: 3750 },
  ]
};

export const MarketTrends: React.FC = () => {
  const [region, setRegion] = React.useState<'Metropolitana' | 'Biobío'>('Metropolitana');

  return (
    <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 h-[350px] md:h-[400px]">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h2 className="text-lg md:text-xl font-semibold text-gray-800">Tendencias (UF/m²)</h2>
        <div className="flex gap-2">
          {['Metropolitana', 'Biobío'].map(r => (
            <button
              key={r}
              onClick={() => setRegion(r as any)}
              className={`px-3 py-1 rounded-full text-[10px] font-bold transition-colors ${
                region === r 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <LineChart data={data[region]}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
          <XAxis 
            dataKey="month" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#9ca3af', fontSize: 12 }}
          />
          <YAxis 
            axisLine={false} 
            tickLine={false} 
            tick={{ fill: '#9ca3af', fontSize: 12 }}
            domain={['dataMin - 100', 'dataMax + 100']}
          />
          <Tooltip 
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
          />
          <Line 
            type="monotone" 
            dataKey="price" 
            stroke="#2563eb" 
            strokeWidth={3} 
            dot={{ r: 4, fill: '#2563eb', strokeWidth: 2, stroke: '#fff' }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
